package com.sample.constructor.based.example.services;

public class HelloWorld {
	private Person person;

	/*public HelloWorld(Person person) {
		this.person = person;
	}*/

	public void setPerson(Person person) {
		this.person = person;
	}

	public String toString() {
		return " HelloWorld ! Here's the person details : \n " + person;
	}
}