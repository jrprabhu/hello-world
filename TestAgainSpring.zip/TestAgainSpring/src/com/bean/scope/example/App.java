package com.bean.scope.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		//Beans-SDI.xml
		//while changing to setter based, do comment the constructors for Person and HelloWorld
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans-scopes.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		helloWorld.setPerson(new Person("Jekyll"));
		System.out.println("helloWorld : " + helloWorld);
		
		HelloWorld helloWorld3 = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println("Before reSetting : " + helloWorld3);
		helloWorld3.setPerson(new Person("Hyde"));
		System.out.println("After reSetting : " + helloWorld3);
		
		HelloWorld helloWorld2 = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld2);
		
	}
}