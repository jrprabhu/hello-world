package com.bean.scope.example;

public class Person {
	private String name;
	/*private String telephoneNumber;
	private int age;
*/
/*	public Person(String name, String telephoneNumber, int age) {
		this.name = name;
		this.telephoneNumber = telephoneNumber;
		this.age = age;
	}*/
	
	public Person(String name) {
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return "Name : " + name;
	}
}