package com.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class HelloWorld {
	
	@Autowired
	private Person person;	

	public String toString() {
		return " HelloWorld ! Here's the person details : \n " + person;
	}
}