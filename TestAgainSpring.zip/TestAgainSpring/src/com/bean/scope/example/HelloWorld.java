package com.bean.scope.example;

public class HelloWorld {
	private Person person;

	public void setPerson(Person person) {
		this.person = person;
	}

	public String toString() {
		return "Here's the person details : \n " + person;
	}
}