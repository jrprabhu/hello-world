package com.tutorialspoint;

public abstract class SampleAbstract {

	private void privateMethod()
	{
		
	}
	
	
	public static void main(String args[])
	{
		System.out.println("Abstract output");
	}
}
