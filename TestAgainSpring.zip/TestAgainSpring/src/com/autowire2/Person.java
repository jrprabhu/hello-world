package com.autowire2;

public class Person {
	private String name;
	private String telephoneNumber;
	private int age;

	public void setName(String name) {
		this.name = name;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "Name : " + name + " \n telephoneNumber : " + telephoneNumber
				+ "\n age : " + age;
	}
}