package com.java.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		/*//Beans-SDI.xml
		//while changing to setter based, do comment the constructors for Person and HelloWorld
		 ApplicationContext context = new ClassPathXmlApplicationContext("Beans-spel.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld);
		 */
		ApplicationContext ctx = new AnnotationConfigApplicationContext(HelloWorldConfig.class);
		HelloWorld helloWorld = ctx.getBean(HelloWorld.class);
		System.out.println(helloWorld);
		
	}
}