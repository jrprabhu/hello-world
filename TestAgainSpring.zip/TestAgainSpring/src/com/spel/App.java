package com.spel;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
	
			ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("Beans-spel.xml");
			Author author = (Author) context.getBean("author");
			System.out.println(author.toString());
			context.close();
	}
}