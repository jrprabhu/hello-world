package com.autowire.example;

public class Person {
	private String name;
	
	public Person() {
		System.out.println("In Person()");
	}

	public void displayPerson() {
		System.out.println("In displayPerson()");
	}

	public String toString() {
		return "Name : " + name;
	}
}