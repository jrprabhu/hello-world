package com.sample.constructor.based.example.services;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.sample.constructor.based.example.services.HelloWorld;

public class App {
	public static void main(String[] args) {
		//Beans-SDI.xml
		//while changing to setter based, do comment the constructors for Person and HelloWorld
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans-CDI.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld);
	}
}