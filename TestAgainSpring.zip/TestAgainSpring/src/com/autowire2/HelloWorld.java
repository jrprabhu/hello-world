package com.autowire2;

public class HelloWorld {
	private Person person;

	/*
	 * enable this for by constructor type
	 * public HelloWorld(Person person)
	{
		this.person=person;
	}*/
		
	public void setPerson(Person person) {
		this.person = person;
	}

	public String toString() {
		return " HelloWorld ! Here's the person details : \n " + person;
	}
}