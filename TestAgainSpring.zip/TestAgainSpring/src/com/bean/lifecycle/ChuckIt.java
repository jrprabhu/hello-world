package com.bean.lifecycle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class ChuckIt implements InitializingBean, DisposableBean, BeanFactoryAware, BeanNameAware, ApplicationContextAware {
	
	private String message;
	
	public String getMessage() {
		System.out.println("Your Message was : " + message);
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	//init method
	public void init(){
	      System.out.println("Bean's getting through init() !");
	   }
	
	@Override
	public void destroy() throws Exception {
		System.out.println("Bean's getting destroy() !!");
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("afterPropertiesSet");
		
	}

	@Override
	public void setBeanFactory(BeanFactory paramBeanFactory)
			throws BeansException {
		System.out.println("setBeanFactory");
		
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
		System.out.println("setApplicationContext");
		
	}

	@Override
	public void setBeanName(String paramString) {
		System.out.println("setBeanName");
		
	}
}
