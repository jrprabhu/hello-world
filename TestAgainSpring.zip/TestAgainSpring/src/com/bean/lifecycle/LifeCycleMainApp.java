package com.bean.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LifeCycleMainApp {

	public static void main(String[] args) {
		AbstractApplicationContext  context = new ClassPathXmlApplicationContext("Beans-Life.xml");

		ChuckIt chuckIt = (ChuckIt) context.getBean("chuckIt");
		chuckIt.getMessage();
		context.registerShutdownHook();
		//Here you need to register a shutdown hook registerShutdownHook() method that is declared on the AbstractApplicationContext class. 
		//This will ensure a graceful shutdown and call the relevant destroy methods.
	}

}
