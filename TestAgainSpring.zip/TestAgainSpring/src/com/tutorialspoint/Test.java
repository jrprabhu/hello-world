package com.tutorialspoint;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		// TODO Auto-generated method stub
		FinalizeExample finalizeExample = new FinalizeExample();
		
		/*String[] argObjects = {"1","2"};
		
		Method method = finalizeExample.getClass().getDeclaredMethod("add", String.class, String.class);
		method.setAccessible(true);
		System.out.println(method.invoke(finalizeExample, argObjects));
		*/
		
		Integer integer = new Integer(0);
		int[] argObjects = {20,1};
		Method method = integer.getClass().getDeclaredMethod("toUnsignedString0", int.class, int.class);
		method.setAccessible(true);
		System.out.println(method.invoke(integer, argObjects));
		
		
	}

}
