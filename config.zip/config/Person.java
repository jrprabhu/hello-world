package com.java.config;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;

public class Person {
	private String name;
	private String telephoneNumber;
	private int age;
	private Address address;
	
	@Required
	@Value(value="Steve")
	public void setName(String name) {
		this.name = name;
	}
	
	@Value(value="001")
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	
	@Value(value="89")
	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "Name : " + name + " \n telephoneNumber : " + telephoneNumber
				+ "\n age : " + age;
	}
}