package com.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class HelloWorld {
	
	//try commenting qualifier
	
	@Autowired
	//@Qualifier("person1")
	private Person person;

	public String toString() {
		return " HelloWorld ! Here's the person details : \n " + person;
	}
}