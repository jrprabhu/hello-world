package com.autowire.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		//Beans-SDI.xml
		//while changing to setter based, do comment the constructors for Person and HelloWorld
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans-autoWire.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		helloWorld.toString();
	}
}