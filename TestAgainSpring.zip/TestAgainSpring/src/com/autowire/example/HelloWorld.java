package com.autowire.example;

public class HelloWorld {
	private Person person;

	public void setPerson(Person person) {
		this.person = person;
	}

	public String toString() {
		person.displayPerson();
		return "Here's the person details : \n " + person;
	}
}