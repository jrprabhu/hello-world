package com.autowire2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		//Beans-SDI.xml
		//while changing to setter based, do comment the constructors for Person and HelloWorld
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans-auto_2.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		System.out.println(helloWorld);
	}
}