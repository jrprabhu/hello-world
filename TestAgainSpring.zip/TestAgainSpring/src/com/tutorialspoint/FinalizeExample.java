package com.tutorialspoint;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

class FinalizeExample {
	public void finalize() {
		System.out.println("finalize called");
	}
	
	public int dass()
	{
		throw new UnsupportedOperationException("Not yet implemented");
	}
	
	
	private String add(String a, String b){
		return a+b;
	}

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		/*List arrayList = new ArrayList();
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		
		HashMap hashmap = new HashMap();
		hashmap.put(1, 2);
		hashmap.put(2, 3);
		
		
		Set set = new HashSet();
		set.add(23);
		
		List list = new ArrayList();
		list.add(2);
		list.add(3);
		
		System.out.println(arrayList);
		
		System.out.println(list);
		
		
		arrayList.removeAll(list);
		System.out.println(arrayList);
		
		arrayList.addAll(set);
		System.out.println(arrayList);*/
		
		Class[] argTypes = {};
		
		/*FinalizeExample finalizeExample = new FinalizeExample();
		
		String[] argObjects = {"1","2"};
		
		Method method = finalizeExample.getClass().getDeclaredMethod("add", String.class, String.class);
		method.setAccessible(true);
		System.out.println(method.invoke(finalizeExample, argObjects));*/
		
	}
}